#ifndef MAKERTF_H
#define MAKERTF_H

extern char rtfheader[256];
extern char *rtf_language_header;

int write_rtf(char *filename);

#endif
