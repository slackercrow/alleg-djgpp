#ifndef MAKETXT_H
#define MAKETXT_H

int write_txt(char *filename, int partial);

#endif
